import { useState, useEffect, useCallback } from 'react';
import {
  GitCompare, ArrowRight, CheckCircle, AlertTriangle, TrendingUp, TrendingDown,
  Minus, Globe, Shield, Award, Clock, ChevronRight,
} from 'lucide-react';
import type { Assessment } from '@/lib/types';
import { loadRecentScans } from '@/lib/fetcher';

interface DiffFinding {
  id: string;
  title: string;
  severity: string;
  ruleId: string;
  status: 'new' | 'resolved' | 'unchanged' | 'changed';
  oldSeverity?: string;
}

export function ScanComparison() {
  const [scans, setScans] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);
  const [scanAId, setScanAId] = useState<string>('');
  const [scanBId, setScanBId] = useState<string>('');

  const refresh = useCallback(async () => {
    setLoading(true);
    const recent = await loadRecentScans(30).catch(() => []);
    setScans(recent);
    if (recent.length >= 2) {
      setScanAId(recent[recent.length - 1].id);
      setScanBId(recent[0].id);
    }
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const scanA = scans.find((s) => s.id === scanAId);
  const scanB = scans.find((s) => s.id === scanBId);

  const diff = computeDiff(scanA, scanB);

  if (loading) {
    return (
      <div className="text-center py-16 text-slate-500">
        <GitCompare className="w-8 h-8 mx-auto mb-3 animate-spin text-slate-600" />
        <p className="text-sm">Loading scans...</p>
      </div>
    );
  }

  if (scans.length < 2) {
    return (
      <div className="text-center py-16 text-slate-500">
        <GitCompare className="w-12 h-12 mx-auto mb-4 text-slate-700" />
        <p className="text-lg text-slate-400">Need at least 2 scans to compare</p>
        <p className="text-sm mt-1">Run scans on the same target to see what changed over time.</p>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-1">Scan Comparison</h2>
        <p className="text-sm text-slate-500">Compare two scans side-by-side to see what improved or regressed</p>
      </div>

      {/* Scan selectors */}
      <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur mb-6">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Baseline Scan (Older)</label>
            <select
              value={scanAId}
              onChange={(e) => setScanAId(e.target.value)}
              className="w-full bg-slate-950/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-slate-200 focus:border-cyan-500/50 focus:outline-none transition"
            >
              {scans.map((s) => (
                <option key={s.id} value={s.id}>{s.finalUrl} — {new Date(s.scannedAt).toLocaleDateString()} (Grade {s.grade})</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Comparison Scan (Newer)</label>
            <select
              value={scanBId}
              onChange={(e) => setScanBId(e.target.value)}
              className="w-full bg-slate-950/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-slate-200 focus:border-cyan-500/50 focus:outline-none transition"
            >
              {scans.map((s) => (
                <option key={s.id} value={s.id}>{s.finalUrl} — {new Date(s.scannedAt).toLocaleDateString()} (Grade {s.grade})</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {diff && (
        <>
          {/* Summary comparison */}
          <div className="grid sm:grid-cols-2 gap-4 mb-6">
            <ScanSummaryCard scan={scanA!} label="Baseline" />
            <ScanSummaryCard scan={scanB!} label="Comparison" />
          </div>

          {/* Delta cards */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-3 mb-6">
            <DeltaCard label="Score" oldVal={scanA!.score} newVal={scanB!.score} suffix="/100" higherIsBetter />
            <DeltaCard label="Total Issues" oldVal={scanA!.totalIssues} newVal={scanB!.totalIssues} />
            <DeltaCard label="Critical" oldVal={scanA!.severityCounts.critical} newVal={scanB!.severityCounts.critical} />
            <DeltaCard label="High" oldVal={scanA!.severityCounts.high} newVal={scanB!.severityCounts.high} />
            <DeltaCard label="Medium" oldVal={scanA!.severityCounts.medium} newVal={scanB!.severityCounts.medium} />
          </div>

          {/* Findings diff */}
          <div className="grid lg:grid-cols-2 gap-4">
            {/* New findings */}
            <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur">
              <h3 className="text-sm font-bold text-red-400 mb-3 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" /> New Issues ({diff.newFindings.length})
              </h3>
              {diff.newFindings.length === 0 ? (
                <p className="text-sm text-slate-500">No new issues detected.</p>
              ) : (
                <div className="space-y-2">
                  {diff.newFindings.map((f) => (
                    <div key={f.id} className="bg-red-500/5 border border-red-500/10 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${severityColor(f.severity)}`}>{f.severity}</span>
                        <span className="text-xs text-slate-300 font-medium">{f.title}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Resolved findings */}
            <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur">
              <h3 className="text-sm font-bold text-emerald-400 mb-3 flex items-center gap-2">
                <TrendingDown className="w-4 h-4" /> Resolved Issues ({diff.resolvedFindings.length})
              </h3>
              {diff.resolvedFindings.length === 0 ? (
                <p className="text-sm text-slate-500">No issues were resolved.</p>
              ) : (
                <div className="space-y-2">
                  {diff.resolvedFindings.map((f) => (
                    <div key={f.id} className="bg-emerald-500/5 border border-emerald-500/10 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${severityColor(f.severity)}`}>{f.severity}</span>
                        <span className="text-xs text-slate-300 font-medium">{f.title}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Changed severity */}
          {diff.changedFindings.length > 0 && (
            <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur mt-4">
              <h3 className="text-sm font-bold text-amber-400 mb-3 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" /> Severity Changed ({diff.changedFindings.length})
              </h3>
              <div className="space-y-2">
                {diff.changedFindings.map((f) => (
                  <div key={f.id} className="bg-amber-500/5 border border-amber-500/10 rounded-lg p-3 flex items-center gap-3">
                    <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${severityColor(f.oldSeverity!)}`}>{f.oldSeverity}</span>
                    <ArrowRight className="w-3 h-3 text-slate-500" />
                    <span className={`text-[10px] font-bold uppercase px-1.5 py-0.5 rounded ${severityColor(f.severity)}`}>{f.severity}</span>
                    <span className="text-xs text-slate-300 font-medium">{f.title}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Verdict */}
          <div className={`mt-6 rounded-2xl p-5 border ${diff.overall === 'improved' ? 'bg-emerald-500/10 border-emerald-500/30' : diff.overall === 'regressed' ? 'bg-red-500/10 border-red-500/30' : 'bg-slate-800/30 border-slate-700/30'}`}>
            <div className="flex items-center gap-3">
              {diff.overall === 'improved' ? <CheckCircle className="w-6 h-6 text-emerald-400" /> : diff.overall === 'regressed' ? <AlertTriangle className="w-6 h-6 text-red-400" /> : <Minus className="w-6 h-6 text-slate-400" />}
              <div>
                <h3 className={`text-lg font-bold ${diff.overall === 'improved' ? 'text-emerald-400' : diff.overall === 'regressed' ? 'text-red-400' : 'text-slate-300'}`}>
                  {diff.overall === 'improved' ? 'Security Posture Improved' : diff.overall === 'regressed' ? 'Security Posture Regressed' : 'No Net Change'}
                </h3>
                <p className="text-sm text-slate-400">
                  {diff.newFindings.length} new issue(s), {diff.resolvedFindings.length} resolved, {diff.changedFindings.length} severity change(s)
                </p>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function ScanSummaryCard({ scan, label }: { scan: Assessment; label: string }) {
  return (
    <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur">
      <div className="flex items-center justify-between mb-3">
        <span className="text-xs uppercase tracking-wide text-slate-500 font-semibold">{label}</span>
        <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg" style={{ background: gradeColor(scan.grade) }}>
          {scan.grade}
        </div>
      </div>
      <p className="text-sm text-slate-300 truncate mb-1">{scan.finalUrl}</p>
      <p className="text-xs text-slate-500 mb-3">{new Date(scan.scannedAt).toLocaleString()}</p>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div><div className="text-lg font-bold text-white">{scan.score}</div><div className="text-[10px] text-slate-500">Score</div></div>
        <div><div className="text-lg font-bold text-red-400">{scan.severityCounts.critical}</div><div className="text-[10px] text-slate-500">Critical</div></div>
        <div><div className="text-lg font-bold text-orange-400">{scan.severityCounts.high}</div><div className="text-[10px] text-slate-500">High</div></div>
      </div>
    </div>
  );
}

function DeltaCard({ label, oldVal, newVal, suffix = '', higherIsBetter = false }: { label: string; oldVal: number; newVal: number; suffix?: string; higherIsBetter?: boolean }) {
  const delta = newVal - oldVal;
  const isPositive = delta > 0;
  const isNegative = delta < 0;
  const improved = higherIsBetter ? isPositive : isNegative;
  const regressed = higherIsBetter ? isNegative : isPositive;

  return (
    <div className="bg-slate-900/40 border border-slate-700/30 rounded-xl p-4 backdrop-blur">
      <div className="text-xs text-slate-500 mb-1">{label}</div>
      <div className="flex items-baseline gap-2">
        <span className="text-xl font-bold text-white tabular-nums">{newVal}{suffix}</span>
        {delta !== 0 && (
          <span className={`text-xs font-mono flex items-center gap-0.5 ${improved ? 'text-emerald-400' : regressed ? 'text-red-400' : 'text-slate-400'}`}>
            {isPositive ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {isPositive ? '+' : ''}{delta}
          </span>
        )}
        {delta === 0 && <Minus className="w-3 h-3 text-slate-600" />}
      </div>
      <div className="text-[10px] text-slate-600 mt-0.5">was {oldVal}{suffix}</div>
    </div>
  );
}

function computeDiff(scanA?: Assessment, scanB?: Assessment) {
  if (!scanA || !scanB) return null;

  const mapA = new Map(scanA.findings.map((f) => [f.ruleId, f]));
  const mapB = new Map(scanB.findings.map((f) => [f.ruleId, f]));

  const newFindings: DiffFinding[] = [];
  const resolvedFindings: DiffFinding[] = [];
  const changedFindings: DiffFinding[] = [];
  const unchangedCount: number[] = [];

  for (const [ruleId, fB] of mapB) {
    const fA = mapA.get(ruleId);
    if (!fA) {
      newFindings.push({ id: fB.id, title: fB.title, severity: fB.severity, ruleId, status: 'new' });
    } else if (fA.severity !== fB.severity) {
      changedFindings.push({ id: fB.id, title: fB.title, severity: fB.severity, ruleId, status: 'changed', oldSeverity: fA.severity });
    } else {
      unchangedCount.push(1);
    }
  }

  for (const [ruleId, fA] of mapA) {
    if (!mapB.has(ruleId)) {
      resolvedFindings.push({ id: fA.id, title: fA.title, severity: fA.severity, ruleId, status: 'resolved' });
    }
  }

  const scoreDelta = scanB.score - scanA.score;
  const issueDelta = scanB.totalIssues - scanA.totalIssues;
  const overall: 'improved' | 'regressed' | 'unchanged' = scoreDelta > 0 || (scoreDelta === 0 && issueDelta < 0) ? 'improved' : scoreDelta < 0 || issueDelta > 0 ? 'regressed' : 'unchanged';

  return { newFindings, resolvedFindings, changedFindings, unchangedCount: unchangedCount.length, overall };
}

function severityColor(sev: string): string {
  return sev === 'critical' ? 'bg-red-500/20 text-red-400' :
    sev === 'high' ? 'bg-orange-500/20 text-orange-400' :
    sev === 'medium' ? 'bg-amber-500/20 text-amber-400' :
    sev === 'low' ? 'bg-cyan-500/20 text-cyan-400' :
    'bg-slate-500/20 text-slate-400';
}

function gradeColor(grade: string): string {
  if (grade.startsWith('A')) return '#10b981';
  if (grade.startsWith('B')) return '#84cc16';
  if (grade.startsWith('C')) return '#eab308';
  if (grade.startsWith('D')) return '#f97316';
  return '#dc2626';
}
