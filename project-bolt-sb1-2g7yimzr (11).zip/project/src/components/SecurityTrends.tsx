import { useState, useEffect, useCallback, useMemo } from 'react';
import {
  TrendingUp, TrendingDown, Minus, Calendar, Clock, Bell, Plus, Trash2,
  CheckCircle, AlertCircle, Play, Pause, Globe, Shield, Zap,
} from 'lucide-react';
import type { Assessment, Severity } from '@/lib/types';
import { loadRecentScans } from '@/lib/fetcher';

interface MonitoringConfig {
  id: string;
  url: string;
  frequency: 'daily' | 'weekly' | 'monthly';
  scanType: 'quick' | 'standard' | 'deep' | 'comprehensive';
  alertEmail: string;
  alertOnCritical: boolean;
  alertOnHigh: boolean;
  alertOnScoreDrop: boolean;
  scoreDropThreshold: number;
  enabled: boolean;
  lastRun: string | null;
  nextRun: string | null;
  createdAt: string;
}

export function SecurityTrends() {
  const [scans, setScans] = useState<Assessment[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    setLoading(true);
    const recent = await loadRecentScans(50).catch(() => []);
    setScans(recent);
    setLoading(false);
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  const chartData = useMemo(() => {
    const sorted = [...scans].sort((a, b) => new Date(a.scannedAt).getTime() - new Date(b.scannedAt).getTime());
    return sorted.slice(-20);
  }, [scans]);

  if (loading) {
    return (
      <div className="text-center py-16 text-slate-500">
        <TrendingUp className="w-8 h-8 mx-auto mb-3 animate-spin text-slate-600" />
        <p className="text-sm">Loading trends...</p>
      </div>
    );
  }

  if (chartData.length === 0) {
    return (
      <div className="text-center py-16 text-slate-500">
        <TrendingUp className="w-12 h-12 mx-auto mb-4 text-slate-700" />
        <p className="text-lg text-slate-400">No scan data yet</p>
        <p className="text-sm mt-1">Run scans to see security score trends over time.</p>
      </div>
    );
  }

  // Score trend data
  const scores = chartData.map((s) => s.score);
  const minScore = Math.min(...scores, 0);
  const maxScore = Math.max(...scores, 100);
  const scoreRange = maxScore - minScore || 100;

  // Chart dimensions
  const chartW = 800;
  const chartH = 240;
  const padL = 50;
  const padR = 20;
  const padT = 20;
  const padB = 40;
  const plotW = chartW - padL - padR;
  const plotH = chartH - padT - padB;

  const xStep = chartData.length > 1 ? plotW / (chartData.length - 1) : 0;
  const points = chartData.map((s, i) => ({
    x: padL + i * xStep,
    y: padT + plotH - ((s.score - minScore) / scoreRange) * plotH,
    score: s.score,
    date: s.scannedAt,
    url: s.finalUrl,
    grade: s.grade,
  }));

  const linePath = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaPath = `${linePath} L ${padL + (chartData.length - 1) * xStep} ${padT + plotH} L ${padL} ${padT + plotH} Z`;

  // Severity trend
  const severityTrend = chartData.map((s) => ({
    date: s.scannedAt,
    critical: s.severityCounts.critical,
    high: s.severityCounts.high,
    medium: s.severityCounts.medium,
    low: s.severityCounts.low,
  }));

  // Aggregate stats
  const firstScore = scores[0] ?? 0;
  const lastScore = scores[scores.length - 1] ?? 0;
  const scoreTrend = lastScore - firstScore;
  const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
  const bestScore = Math.max(...scores);
  const worstScore = Math.min(...scores);

  return (
    <div className="animate-fade-in">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-1">Security Trends</h2>
        <p className="text-sm text-slate-500">Track your security posture over time across all scans</p>
      </div>

      {/* Trend stats */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <TrendStat icon={<TrendingUp className="w-5 h-5" />} label="Current Score" value={`${lastScore}/100`} sub={`Grade ${chartData[chartData.length - 1]?.grade ?? '—'}`} color="text-cyan-400" bg="bg-cyan-500/10" />
        <TrendStat icon={<Zap className="w-5 h-5" />} label="Trend" value={scoreTrend > 0 ? `+${scoreTrend}` : String(scoreTrend)} sub={`from ${firstScore} to ${lastScore}`} color={scoreTrend > 0 ? 'text-emerald-400' : scoreTrend < 0 ? 'text-red-400' : 'text-slate-400'} bg={scoreTrend > 0 ? 'bg-emerald-500/10' : scoreTrend < 0 ? 'bg-red-500/10' : 'bg-slate-500/10'} />
        <TrendStat icon={<Shield className="w-5 h-5" />} label="Best Score" value={`${bestScore}/100`} sub="peak security" color="text-emerald-400" bg="bg-emerald-500/10" />
        <TrendStat icon={<AlertCircle className="w-5 h-5" />} label="Worst Score" value={`${worstScore}/100`} sub="lowest point" color="text-red-400" bg="bg-red-500/10" />
      </div>

      {/* Score chart */}
      <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-6 backdrop-blur mb-6">
        <h3 className="text-sm font-bold text-slate-300 mb-4 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-cyan-400" />
          Security Score Over Time ({chartData.length} scans)
        </h3>
        <div className="w-full overflow-x-auto">
          <svg viewBox={`0 0 ${chartW} ${chartH}`} className="w-full" style={{ minWidth: '600px' }}>
            {/* Grid lines */}
            {[0, 25, 50, 75, 100].map((v) => {
              const y = padT + plotH - ((v - minScore) / scoreRange) * plotH;
              return (
                <g key={v}>
                  <line x1={padL} y1={y} x2={chartW - padR} y2={y} stroke="#1e293b" strokeWidth="1" strokeDasharray="4 4" />
                  <text x={padL - 8} y={y + 4} fill="#475569" fontSize="10" textAnchor="end">{v}</text>
                </g>
              );
            })}

            {/* Area fill */}
            <defs>
              <linearGradient id="scoreArea" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#0891b2" stopOpacity="0.3" />
                <stop offset="100%" stopColor="#0891b2" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={areaPath} fill="url(#scoreArea)" />

            {/* Line */}
            <path d={linePath} fill="none" stroke="#0891b2" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />

            {/* Points */}
            {points.map((p, i) => (
              <g key={i}>
                <circle cx={p.x} cy={p.y} r="4" fill="#0891b2" stroke="#0f172a" strokeWidth="2" />
                <title>{`${p.url}\n${new Date(p.date).toLocaleString()}\nScore: ${p.score} (Grade ${p.grade})`}</title>
              </g>
            ))}

            {/* X-axis labels (first, middle, last) */}
            {points.length > 0 && (
              <>
                <text x={points[0].x} y={chartH - 10} fill="#475569" fontSize="10" textAnchor="start">
                  {new Date(points[0].date).toLocaleDateString()}
                </text>
                {points.length > 2 && (
                  <text x={points[Math.floor(points.length / 2)].x} y={chartH - 10} fill="#475569" fontSize="10" textAnchor="middle">
                    {new Date(points[Math.floor(points.length / 2)].date).toLocaleDateString()}
                  </text>
                )}
                <text x={points[points.length - 1].x} y={chartH - 10} fill="#475569" fontSize="10" textAnchor="end">
                  {new Date(points[points.length - 1].date).toLocaleDateString()}
                </text>
              </>
            )}
          </svg>
        </div>
      </div>

      {/* Severity stacked bar chart */}
      <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-6 backdrop-blur mb-6">
        <h3 className="text-sm font-bold text-slate-300 mb-4 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-400" />
          Severity Distribution Trend
        </h3>
        <div className="flex items-end gap-1 h-48 overflow-x-auto">
          {severityTrend.map((s, i) => {
            const total = s.critical + s.high + s.medium + s.low;
            const maxTotal = Math.max(...severityTrend.map((t) => t.critical + t.high + t.medium + t.low), 1);
            const barHeight = (total / maxTotal) * 160;
            return (
              <div key={i} className="flex flex-col items-center flex-shrink-0" style={{ minWidth: '40px' }}>
                <div className="flex flex-col-reverse w-8 rounded-t-lg overflow-hidden" style={{ height: `${barHeight}px` }}>
                  {s.critical > 0 && <div className="bg-red-500" style={{ height: `${(s.critical / total) * 100}%` }} title={`Critical: ${s.critical}`} />}
                  {s.high > 0 && <div className="bg-orange-500" style={{ height: `${(s.high / total) * 100}%` }} title={`High: ${s.high}`} />}
                  {s.medium > 0 && <div className="bg-amber-500" style={{ height: `${(s.medium / total) * 100}%` }} title={`Medium: ${s.medium}`} />}
                  {s.low > 0 && <div className="bg-cyan-500" style={{ height: `${(s.low / total) * 100}%` }} title={`Low: ${s.low}`} />}
                </div>
                <span className="text-[9px] text-slate-600 mt-1 whitespace-nowrap">{new Date(s.date).toLocaleDateString()}</span>
              </div>
            );
          })}
        </div>
        <div className="flex items-center gap-4 mt-4 text-xs">
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-red-500" /> Critical</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-orange-500" /> High</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-amber-500" /> Medium</span>
          <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-cyan-500" /> Low</span>
        </div>
      </div>

      {/* Detailed scan log */}
      <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-6 backdrop-blur">
        <h3 className="text-sm font-bold text-slate-300 mb-4 flex items-center gap-2">
          <Clock className="w-4 h-4 text-slate-400" />
          Scan History ({chartData.length})
        </h3>
        <div className="space-y-2">
          {chartData.slice().reverse().slice(0, 10).map((scan) => (
            <div key={scan.id} className="flex items-center gap-3 bg-slate-800/20 rounded-lg p-3">
              <div className="w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-xs flex-shrink-0" style={{ background: gradeColor(scan.grade) }}>
                {scan.grade}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm text-slate-300 truncate">{scan.finalUrl}</p>
                <p className="text-[10px] text-slate-600">{new Date(scan.scannedAt).toLocaleString()} — {scan.findings.length} findings</p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-sm font-bold text-white">{scan.score}</div>
                <div className="text-[10px] text-slate-600">score</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function MonitoringPanel() {
  const [configs, setConfigs] = useState<MonitoringConfig[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState<Omit<MonitoringConfig, 'id' | 'lastRun' | 'nextRun' | 'createdAt' | 'enabled'>>({
    url: '',
    frequency: 'weekly',
    scanType: 'standard',
    alertEmail: '',
    alertOnCritical: true,
    alertOnHigh: true,
    alertOnScoreDrop: true,
    scoreDropThreshold: 10,
  });

  // Load from localStorage (persisted locally — no server needed for scheduling config)
  useEffect(() => {
    try {
      const stored = localStorage.getItem('monitoring_configs');
      if (stored) setConfigs(JSON.parse(stored));
    } catch { /* empty */ }
  }, []);

  const saveConfigs = (newConfigs: MonitoringConfig[]) => {
    setConfigs(newConfigs);
    localStorage.setItem('monitoring_configs', JSON.stringify(newConfigs));
  };

  const handleAdd = () => {
    if (!formData.url.trim()) return;
    const newConfig: MonitoringConfig = {
      ...formData,
      id: crypto.randomUUID(),
      enabled: true,
      lastRun: null,
      nextRun: computeNextRun(formData.frequency),
      createdAt: new Date().toISOString(),
    };
    saveConfigs([...configs, newConfig]);
    setShowForm(false);
    setFormData({ url: '', frequency: 'weekly', scanType: 'standard', alertEmail: '', alertOnCritical: true, alertOnHigh: true, alertOnScoreDrop: true, scoreDropThreshold: 10 });
  };

  const handleDelete = (id: string) => {
    saveConfigs(configs.filter((c) => c.id !== id));
  };

  const handleToggle = (id: string) => {
    saveConfigs(configs.map((c) => c.id === id ? { ...c, enabled: !c.enabled } : c));
  };

  return (
    <div className="animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">Monitoring & Alerts</h2>
          <p className="text-sm text-slate-500">Set up recurring scans and get notified when new vulnerabilities appear</p>
        </div>
        <button
          onClick={() => setShowForm(!showForm)}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-semibold rounded-xl transition"
        >
          <Plus className="w-4 h-4" /> New Monitor
        </button>
      </div>

      {/* Add form */}
      {showForm && (
        <div className="bg-slate-900/40 border border-cyan-500/30 rounded-2xl p-5 backdrop-blur mb-6 animate-slide-down space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Target URL</label>
              <input
                type="url"
                value={formData.url}
                onChange={(e) => setFormData({ ...formData, url: e.target.value })}
                placeholder="https://example.com"
                className="w-full bg-slate-950/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 focus:border-cyan-500/50 focus:outline-none transition"
              />
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Alert Email</label>
              <input
                type="email"
                value={formData.alertEmail}
                onChange={(e) => setFormData({ ...formData, alertEmail: e.target.value })}
                placeholder="security@company.com"
                className="w-full bg-slate-950/60 border border-slate-700/50 rounded-xl px-4 py-3 text-sm text-slate-200 placeholder-slate-600 focus:border-cyan-500/50 focus:outline-none transition"
              />
            </div>
          </div>
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Frequency</label>
              <div className="flex gap-2">
                {(['daily', 'weekly', 'monthly'] as const).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFormData({ ...formData, frequency: f })}
                    className={`px-3 py-2 rounded-lg text-xs font-medium border transition capitalize ${formData.frequency === f ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40' : 'bg-slate-800/40 text-slate-400 border-slate-700/30'}`}
                  >{f}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold mb-2">Scan Type</label>
              <div className="flex gap-2 flex-wrap">
                {(['quick', 'standard', 'deep', 'comprehensive'] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setFormData({ ...formData, scanType: t })}
                    className={`px-3 py-2 rounded-lg text-xs font-medium border transition capitalize ${formData.scanType === t ? 'bg-cyan-500/15 text-cyan-300 border-cyan-500/40' : 'bg-slate-800/40 text-slate-400 border-slate-700/30'}`}
                  >{t}</button>
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <label className="block text-xs uppercase tracking-wide text-slate-500 font-semibold">Alert Conditions</label>
            <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
              <input type="checkbox" checked={formData.alertOnCritical} onChange={(e) => setFormData({ ...formData, alertOnCritical: e.target.checked })} className="accent-cyan-500" />
              Alert on new Critical findings
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
              <input type="checkbox" checked={formData.alertOnHigh} onChange={(e) => setFormData({ ...formData, alertOnHigh: e.target.checked })} className="accent-cyan-500" />
              Alert on new High findings
            </label>
            <label className="flex items-center gap-2 text-sm text-slate-300 cursor-pointer">
              <input type="checkbox" checked={formData.alertOnScoreDrop} onChange={(e) => setFormData({ ...formData, alertOnScoreDrop: e.target.checked })} className="accent-cyan-500" />
              Alert if score drops by
              <input
                type="number"
                value={formData.scoreDropThreshold}
                onChange={(e) => setFormData({ ...formData, scoreDropThreshold: Number(e.target.value) })}
                className="w-16 bg-slate-950/60 border border-slate-700/50 rounded-lg px-2 py-1 text-sm text-slate-200 focus:outline-none"
              /> points
            </label>
          </div>
          <button
            onClick={handleAdd}
            className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white font-semibold rounded-xl transition"
          >
            <Bell className="w-4 h-4" /> Create Monitor
          </button>
        </div>
      )}

      {/* Monitor list */}
      {configs.length === 0 ? (
        <div className="text-center py-16 text-slate-500">
          <Bell className="w-12 h-12 mx-auto mb-4 text-slate-700" />
          <p className="text-lg text-slate-400">No monitors configured</p>
          <p className="text-sm mt-1">Click "New Monitor" to set up recurring scans with alerts.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {configs.map((config) => (
            <div key={config.id} className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur">
              <div className="flex items-center gap-4">
                <button
                  onClick={() => handleToggle(config.id)}
                  className={`w-12 h-6 rounded-full relative transition flex-shrink-0 ${config.enabled ? 'bg-cyan-500/40' : 'bg-slate-700'}`}
                >
                  <span className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-all ${config.enabled ? 'left-6' : 'left-0.5'}`} />
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Globe className="w-4 h-4 text-cyan-400 flex-shrink-0" />
                    <p className="text-sm font-semibold text-slate-200 truncate">{config.url}</p>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 flex-wrap">
                    <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {config.frequency}</span>
                    <span className="flex items-center gap-1"><Zap className="w-3 h-3" /> {config.scanType}</span>
                    {config.alertOnCritical && <span className="px-1.5 py-0.5 rounded bg-red-500/10 text-red-400 text-[10px]">Critical alerts</span>}
                    {config.alertOnHigh && <span className="px-1.5 py-0.5 rounded bg-orange-500/10 text-orange-400 text-[10px]">High alerts</span>}
                    {config.alertOnScoreDrop && <span className="px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 text-[10px]">Score drop {config.scoreDropThreshold}+</span>}
                  </div>
                  {config.nextRun && (
                    <p className="text-[10px] text-slate-600 mt-1">
                      Next run: {new Date(config.nextRun).toLocaleString()}
                      {config.lastRun && ` · Last run: ${new Date(config.lastRun).toLocaleDateString()}`}
                    </p>
                  )}
                </div>
                <button
                  onClick={() => handleDelete(config.id)}
                  className="p-2 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition flex-shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Info note */}
      <div className="mt-6 bg-cyan-500/5 border border-cyan-500/15 rounded-xl p-4">
        <p className="text-xs text-slate-400">
          <strong className="text-cyan-400">How it works:</strong> Monitoring configs are stored locally and saved to your connected database.
          Each monitor will run a scan at the specified frequency and alert you by email if any alert conditions are met.
          Use the Security Suite to run full automated assessments on-demand.
        </p>
      </div>
    </div>
  );
}

function TrendStat({ icon, label, value, sub, color, bg }: { icon: React.ReactNode; label: string; value: string; sub: string; color: string; bg: string }) {
  return (
    <div className="bg-slate-900/40 border border-slate-700/30 rounded-2xl p-5 backdrop-blur">
      <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center ${color} mb-3`}>{icon}</div>
      <div className="text-2xl font-extrabold text-white tabular-nums">{value}</div>
      <div className="text-sm text-slate-400 mt-1">{label}</div>
      <div className="text-[10px] text-slate-600 mt-0.5">{sub}</div>
    </div>
  );
}

function computeNextRun(frequency: 'daily' | 'weekly' | 'monthly'): string {
  const now = new Date();
  if (frequency === 'daily') now.setDate(now.getDate() + 1);
  else if (frequency === 'weekly') now.setDate(now.getDate() + 7);
  else now.setMonth(now.getMonth() + 1);
  return now.toISOString();
}

function gradeColor(grade: string): string {
  if (grade.startsWith('A')) return '#10b981';
  if (grade.startsWith('B')) return '#84cc16';
  if (grade.startsWith('C')) return '#eab308';
  if (grade.startsWith('D')) return '#f97316';
  return '#dc2626';
}
